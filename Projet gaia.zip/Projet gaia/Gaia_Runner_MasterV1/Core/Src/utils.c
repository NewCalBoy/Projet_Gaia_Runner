/*
 * utils.c
 *
 *  Created on: Mar 7, 2026
 *      Author: SERAPHIN Bradley
 */
//==========================================
//	Vartiables et Include
//==========================================

#include "utils.h"

uint8_t avancer = 0x01;
uint8_t reculer = 0x02;
uint8_t stop = 0x03;
uint8_t augmenter = 0x04;
uint8_t diminuer = 0x05;
uint8_t received_data;


//==========================================
//	Fonctions
//==========================================

void loop(void)
{
	if (HAL_UART_Receive(&huart1, &received_data, 1, HAL_MAX_DELAY) == HAL_OK)
	{
		HAL_UART_Transmit(&huart1, &received_data, 1, HAL_MAX_DELAY);

		switch(received_data)
		{
		case 'F':
			Avancer();
			break;
		case 'B':
			Reculer();
			break;
		case 'L':
			Gauche();
			break;
		case 'R':
			Droite();
			break;
		case 'S':
			Stop();
		case '1':
			Plus();
			break;
		case '2':
			Moins();
			break;
		}
	}
}

void Avancer(void)
{
	HAL_I2C_Master_Transmit(&hi2c1,AVG,&reculer,1,HAL_MAX_DELAY);
	HAL_I2C_Master_Transmit(&hi2c1,AVD,&avancer,1,HAL_MAX_DELAY);
	HAL_I2C_Master_Transmit(&hi2c1,ARG,&reculer,1,HAL_MAX_DELAY);
	HAL_I2C_Master_Transmit(&hi2c1,ARD,&avancer,1,HAL_MAX_DELAY);
}

void Reculer(void)
{
	HAL_I2C_Master_Transmit(&hi2c1,AVG,&avancer,1,HAL_MAX_DELAY);
	HAL_I2C_Master_Transmit(&hi2c1,AVD,&reculer,1,HAL_MAX_DELAY);
	HAL_I2C_Master_Transmit(&hi2c1,ARG,&avancer,1,HAL_MAX_DELAY);
	HAL_I2C_Master_Transmit(&hi2c1,ARD,&reculer,1,HAL_MAX_DELAY);
}

void Stop(void)
{
	HAL_I2C_Master_Transmit(&hi2c1,AVG,&stop,1,HAL_MAX_DELAY);
	HAL_I2C_Master_Transmit(&hi2c1,AVD,&stop,1,HAL_MAX_DELAY);
	HAL_I2C_Master_Transmit(&hi2c1,ARG,&stop,1,HAL_MAX_DELAY);
	HAL_I2C_Master_Transmit(&hi2c1,ARD,&stop,1,HAL_MAX_DELAY);
}

void Droite(void)
{
	HAL_I2C_Master_Transmit(&hi2c1,AVG,&reculer,1,HAL_MAX_DELAY);
	HAL_I2C_Master_Transmit(&hi2c1,AVD,&reculer,1,HAL_MAX_DELAY);
	HAL_I2C_Master_Transmit(&hi2c1,ARG,&reculer,1,HAL_MAX_DELAY);
	HAL_I2C_Master_Transmit(&hi2c1,ARD,&reculer,1,HAL_MAX_DELAY);
}

void Gauche(void)
{
	HAL_I2C_Master_Transmit(&hi2c1,AVG,&avancer,1,HAL_MAX_DELAY);
	HAL_I2C_Master_Transmit(&hi2c1,AVD,&avancer,1,HAL_MAX_DELAY);
	HAL_I2C_Master_Transmit(&hi2c1,ARG,&avancer,1,HAL_MAX_DELAY);
	HAL_I2C_Master_Transmit(&hi2c1,ARD,&avancer,1,HAL_MAX_DELAY);
}

void Plus(void)
{
    HAL_I2C_Master_Transmit(&hi2c1, AVG, &augmenter, 1, HAL_MAX_DELAY);
    HAL_I2C_Master_Transmit(&hi2c1, AVD, &augmenter, 1, HAL_MAX_DELAY);
    HAL_I2C_Master_Transmit(&hi2c1, ARG, &augmenter, 1, HAL_MAX_DELAY);
    HAL_I2C_Master_Transmit(&hi2c1, ARD, &augmenter, 1, HAL_MAX_DELAY);
}

void Moins(void)
{
    HAL_I2C_Master_Transmit(&hi2c1, AVG, &diminuer, 1, HAL_MAX_DELAY);
    HAL_I2C_Master_Transmit(&hi2c1, AVD, &diminuer, 1, HAL_MAX_DELAY);
    HAL_I2C_Master_Transmit(&hi2c1, ARG, &diminuer, 1, HAL_MAX_DELAY);
    HAL_I2C_Master_Transmit(&hi2c1, ARD, &diminuer, 1, HAL_MAX_DELAY);
}


//==========================================
//	Définition des fonctions tests
//==========================================

void test_I2C(void)
{
	//	int button=0;
	//	if (HAL_GPIO_ReadPin(GPIOC, GPIO_PIN_13) == GPIO_PIN_RESET) // Si bouton appuyé
	//		switch(button)
	//		{
	//		case 0:
	//			Avancer();//Avance
	//			button=1;
	//		case 1:
	//			Stop();//Stop
	//			button=2;
	//		case 2:
	//			Reculer();//Reculer
	//			button=3;
	//		case 3:
	//			Stop();//Stop
	//			button=0;
	//		}
	Avancer();
}


void test_HC05(void)
{
	// On utilise un timeout court pour ne pas bloquer le reste
	if (HAL_UART_Receive(&huart1, &received_data, 1, HAL_MAX_DELAY) == HAL_OK)
	{
		// Echo pour debug
		HAL_UART_Transmit(&huart1, &received_data, 1, HAL_MAX_DELAY);

		switch(received_data)
		{
		case 'Z':
			HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, GPIO_PIN_SET);
			break;
		case 'S':
			HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, GPIO_PIN_RESET);
			break;
		case 'Q':
			HAL_GPIO_TogglePin(GPIOA, GPIO_PIN_5);
			break;
		}
	}
}

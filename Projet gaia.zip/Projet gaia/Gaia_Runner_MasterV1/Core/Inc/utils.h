/*
 * utils.h
 *
 *  Created on: Mar 7, 2026
 *      Author: SERAPHIN Bradley
 */

#ifndef INC_UTILS_H_
#define INC_UTILS_H_

#include "main.h"

extern I2C_HandleTypeDef hi2c1;
extern UART_HandleTypeDef huart1;

void test_I2C (void);
void test_HC05(void);
void loop (void);
void Avancer(void);
void Reculer(void);
void Stop(void);
void Gauche(void);
void Droite(void);
void Plus(void);
void Moins(void);

#define AVG (0x10<<1)
#define AVD (0x11<<1)
#define ARG (0x12<<1)
#define ARD (0x13<<1)

#endif /* INC_UTILS_H_ */

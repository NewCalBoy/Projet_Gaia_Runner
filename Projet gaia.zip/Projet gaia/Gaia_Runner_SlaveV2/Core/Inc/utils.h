/*
 * utils.h
 *
 *  Created on: Jan 21, 2026
 *      Author: Utilisateur
 */

#ifndef INC_UTILS_H_
#define INC_UTILS_H_

//-------------------------------------------------
//			Includes
//-------------------------------------------------

#include "main.h"


//-------------------------------------------------
//			Defines
//-------------------------------------------------

//Interne :

#define GPIO GPIOA
#define GPIO_Jumper1 GPIOB
#define Green_LED GPIO_PIN_5
#define AIN1 GPIO_PIN_0
#define AIN2 GPIO_PIN_1
#define Jumper_1 GPIO_PIN_1
#define Jumper_2 GPIO_PIN_2
#define Jumper_3 GPIO_PIN_3

//Externe :

extern I2C_HandleTypeDef hi2c1;
extern TIM_HandleTypeDef htim14;
extern TIM_HandleTypeDef htim3;


//-------------------------------------------------
//			Functions
//-------------------------------------------------

void setup(void);
void loop(void);
void test_loop(void);
void message_receive(void);
void motor_test(void);
void avancer(void);
void reculer(void);
void stop(void);
void I2C_ChangeSlaveAddress(void);
void diminuer_vitesse(void);
void augmenter_vitesse(void);

#endif /* INC_UTILS_H_ */

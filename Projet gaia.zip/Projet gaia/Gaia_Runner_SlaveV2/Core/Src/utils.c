/*
 * utils.c
 *
 *  Created on: Jan 21, 2026
 *      Author: SERAPHIN Bradley
 */

//==========================================
//	Vartiables et Include
//==========================================


#include "utils.h"

static int encoder_last = 0;
static int encoder_now = 0;
static int speed_tcks = 0;
static float speed_rads = 0.0f;
static int delta_time=10;
static int cpr = 24;

//variable encodeur
int32_t encoder_prev = 0;
float speed = 0;

// Correcteur P
float speed_target = 0;
float Kp = 5.0f;  // 1 / tau = 1 / 0.2s ≈ 5

// PWM
uint16_t pwm_output = 0;
uint16_t pwm_value = 500;



//==========================================
//	Fonctions
//==========================================

void setup(void)
{
	//__HAL_TIM_SET_COMPARE(&htim14,TIM_CHANNEL_1, 239);
	I2C_ChangeSlaveAddress();
	HAL_TIM_PWM_Start(&htim14,TIM_CHANNEL_1);
	stop();
}

void loop(void)
{
	message_receive();


}


void message_receive(void)
{
	uint8_t received_data = 0;
	HAL_I2C_Slave_Receive(&hi2c1, &received_data, 1, HAL_MAX_DELAY);
	//	HAL_GPIO_WritePin(GPIO,Green_LED,RESET);
	//	if (received_data == 0x42)
	//	{
	//		HAL_GPIO_WritePin(GPIO,Green_LED,SET);
	//		HAL_Delay(2000);
	//	}
	switch(received_data)
	{
	case 0x01:
		avancer();
		break;

	case 0x02:
		reculer();
		break;

	case 0x03:
		stop();
		break;
    case 0x04:
        augmenter_vitesse();
        break;

    case 0x05:
        diminuer_vitesse();
        break;
	}

}

void message_receive_speed(void)
{
	uint8_t received_data = 0;
	HAL_I2C_Slave_Receive(&hi2c1, &received_data, 1, HAL_MAX_DELAY);

	switch(received_data)
	{
    case 0x01:
        avancer();
        break;

    case 0x02:
        reculer();
        break;

    case 0x03:
        stop();
        break;

    case 0x04:
        augmenter_vitesse();
        break;

    case 0x05:
        diminuer_vitesse();
        break;
	}
}





void I2C_ChangeSlaveAddress(void)
{
	HAL_I2C_DeInit(&hi2c1);

	//Roue Avant Gauche
	if ((HAL_GPIO_ReadPin(GPIO_Jumper1,Jumper_1)==GPIO_PIN_SET)&&(HAL_GPIO_ReadPin(GPIO,Jumper_2)==GPIO_PIN_RESET)&&(HAL_GPIO_ReadPin(GPIO,Jumper_3)==GPIO_PIN_RESET))
	{
		hi2c1.Init.OwnAddress1 = (0x10<<1);//=16
	}

	//Roue Avant Droite
	else if ((HAL_GPIO_ReadPin(GPIO_Jumper1,Jumper_1)==GPIO_PIN_RESET)&&(HAL_GPIO_ReadPin(GPIO,Jumper_2)==GPIO_PIN_SET)&&(HAL_GPIO_ReadPin(GPIO,Jumper_3)==GPIO_PIN_RESET))
	{
		hi2c1.Init.OwnAddress1 = (0x11<<1);//=17
	}

	//Roue Arrière Gauche
	else if ((HAL_GPIO_ReadPin(GPIO_Jumper1,Jumper_1)==GPIO_PIN_RESET)&&(HAL_GPIO_ReadPin(GPIO,Jumper_2)==GPIO_PIN_RESET)&&(HAL_GPIO_ReadPin(GPIO,Jumper_3)==GPIO_PIN_SET))
	{
		hi2c1.Init.OwnAddress1 = (0x12<<1);//=18
	}

	//Roue Arrière Droite
	else if ((HAL_GPIO_ReadPin(GPIO_Jumper1,Jumper_1)==GPIO_PIN_SET)&&(HAL_GPIO_ReadPin(GPIO,Jumper_2)==GPIO_PIN_SET)&&(HAL_GPIO_ReadPin(GPIO,Jumper_3)==GPIO_PIN_RESET))
	{
		hi2c1.Init.OwnAddress1 = (0x13<<1);//=19
	}

	else
	{
		hi2c1.Init.OwnAddress1 = 0x00;
		stop();
		HAL_GPIO_WritePin(GPIO,Green_LED,SET);
	}

	HAL_I2C_Init(&hi2c1);
}




void set_pwm(uint16_t pwm)
{
	if(pwm > 999) pwm = 999;
	__HAL_TIM_SET_COMPARE(&htim14,TIM_CHANNEL_1, pwm);
}

void avancer(void)
{
	HAL_GPIO_WritePin(GPIO, AIN1, 1);
	HAL_GPIO_WritePin(GPIO, AIN2, 0);
	set_pwm(pwm_value);
}

void reculer(void)
{
	HAL_GPIO_WritePin(GPIO, AIN1, 0);
	HAL_GPIO_WritePin(GPIO, AIN2, 1);
	set_pwm(pwm_value);
}

void stop(void)
{
	HAL_GPIO_WritePin(GPIO, AIN1, 0);
	HAL_GPIO_WritePin(GPIO, AIN2,0);
	set_pwm(0);
}

void augmenter_vitesse(void)
{
    pwm_value += 100;
    if(pwm_value > 999) pwm_value = 999;

    set_pwm(pwm_value);
}

void diminuer_vitesse(void)
{
    if(pwm_value > 100)
        pwm_value -= 100;
    else
        pwm_value = 0;

    set_pwm(pwm_value);
}
//==========================================
//	Définition des fonctions pour l'encodeur
//==========================================


int32_t get_delta(int32_t now, int32_t prev)
{
    int32_t delta = now - prev;

    if(delta > 32768) delta -= 65536;
    if(delta < -32768) delta += 65536;

    return delta;
}

float read_speed(void)
{
    int32_t encoder_now = __HAL_TIM_GET_COUNTER(&htim3);
    int32_t delta = get_delta(encoder_now, encoder_prev);

    encoder_prev = encoder_now;

    // vitesse en ticks par période (ex: 10 ms)
    return (float)delta;
}



//void control_speed(void)
//{
//    speed = read_speed();
//    float error = speed_target - speed;
//
//    float command = Kp * error;
//
//    if(command > 1000) command = 1000;
//    if(command < -1000) command = -1000;
//
//    pwm_output = (uint16_t)fabs(command);
//
//    if(command > 0)
//        avancer(pwm_output);
//    else if(command < 0)
//        reculer(pwm_output);
//    else
//        stop();
//}







//==========================================
//	Définition des fonctions tests
//==========================================

void test_loop(void)
{
	//	  printf("Hello World !\r\n");

	//--------TEST_LED+JUMPER--------

	HAL_GPIO_WritePin(GPIO,Green_LED,RESET);
	if ((HAL_GPIO_ReadPin(GPIO_Jumper1,Jumper_1)==GPIO_PIN_SET)&&(HAL_GPIO_ReadPin(GPIO,Jumper_2)==GPIO_PIN_RESET)&&(HAL_GPIO_ReadPin(GPIO,Jumper_3)==GPIO_PIN_RESET))
	{
		HAL_GPIO_WritePin(GPIO,Green_LED,SET);
	}
	else if ((HAL_GPIO_ReadPin(GPIO_Jumper1,Jumper_1)==GPIO_PIN_RESET)&&(HAL_GPIO_ReadPin(GPIO,Jumper_2)==GPIO_PIN_SET)&&(HAL_GPIO_ReadPin(GPIO,Jumper_3)==GPIO_PIN_RESET))
	{
		HAL_GPIO_WritePin(GPIO,Green_LED,SET);
		HAL_Delay(1000);
		HAL_GPIO_WritePin(GPIO,Green_LED,RESET);
		HAL_Delay(1000);
	}
	else if ((HAL_GPIO_ReadPin(GPIO_Jumper1,Jumper_1)==GPIO_PIN_RESET)&&(HAL_GPIO_ReadPin(GPIO,Jumper_2)==GPIO_PIN_RESET)&&(HAL_GPIO_ReadPin(GPIO,Jumper_3)==GPIO_PIN_SET))
	{
		HAL_GPIO_WritePin(GPIO,Green_LED,SET);
		HAL_Delay(300);
		HAL_GPIO_WritePin(GPIO,Green_LED,RESET);
		HAL_Delay(300);
	}

	//--------TEST_MOTEUR+JUMPER--------

	else if ((HAL_GPIO_ReadPin(GPIO_Jumper1,Jumper_1)==GPIO_PIN_RESET)&&(HAL_GPIO_ReadPin(GPIO,Jumper_2)==GPIO_PIN_RESET)&&(HAL_GPIO_ReadPin(GPIO,Jumper_3)==0))
	{
		// Set the rotation direction backward
		HAL_GPIO_WritePin(GPIO, AIN1, 1);
		HAL_GPIO_WritePin(GPIO, AIN2, 0);
		// Set the speed slow
		__HAL_TIM_SET_COMPARE(&htim14,TIM_CHANNEL_1, 1199); //25%
		HAL_Delay(2000);
		// Set the speed medium
		__HAL_TIM_SET_COMPARE(&htim14,TIM_CHANNEL_1, 2399); //50%
		HAL_Delay(2000);
		// Set the speed high
		__HAL_TIM_SET_COMPARE(&htim14,TIM_CHANNEL_1, 3599); //75%
		HAL_Delay(2000);

		HAL_GPIO_WritePin(GPIO, AIN1, 0);
		HAL_GPIO_WritePin(GPIO, AIN2, 0);
		HAL_Delay(2000);
	}

	else if ((HAL_GPIO_ReadPin(GPIO_Jumper1,Jumper_1)==GPIO_PIN_SET)&&(HAL_GPIO_ReadPin(GPIO,Jumper_2)==GPIO_PIN_RESET)&&(HAL_GPIO_ReadPin(GPIO,Jumper_3)==GPIO_PIN_SET))
	{
		//	  printf("A=%d\r\n",HAL_GPIO_ReadPin(GPIOB,GPIO_PIN_9));
		HAL_Delay(delta_time);
		encoder_now =__HAL_TIM_GET_COUNTER(&htim3);
		int diff = -1*(encoder_now - encoder_last);

		// Gestion du débordement 16 bits
		if (diff > 32767)  diff -= 65536;
		if (diff < -32768) diff += 65536;

		// vitesse en ticks / seconde
		speed_tcks = (diff * 1000) / delta_time; // 1000ms=1s
		speed_rads = speed_tcks * (2.0f * 3.1415926f)/cpr;

		encoder_last = encoder_now;

		//	  	  printf("La vitesse est de %d en tick/s\r\n",speed_tcks);
		//	  	  printf("La vitesse est de %d en rad/s\r\n",speed_rads);
		//	  	  printf("===========================================\r\n");

		if (speed_tcks>499){HAL_GPIO_WritePin(GPIO,Green_LED,SET);}
		else {HAL_GPIO_WritePin(GPIO,Green_LED,RESET);}
	}

}

void motor_test(void)
{
	HAL_GPIO_WritePin(GPIO, AIN1, 1);
	HAL_GPIO_WritePin(GPIO, AIN2, 0);
	if ((HAL_GPIO_ReadPin(GPIO_Jumper1,Jumper_1)==GPIO_PIN_SET)&&(HAL_GPIO_ReadPin(GPIO,Jumper_2)==GPIO_PIN_RESET)&&(HAL_GPIO_ReadPin(GPIO,Jumper_3)==GPIO_PIN_RESET))
	{
		__HAL_TIM_SET_COMPARE(&htim14,TIM_CHANNEL_1, 479);
	}
	else if ((HAL_GPIO_ReadPin(GPIO_Jumper1,Jumper_1)==GPIO_PIN_RESET)&&(HAL_GPIO_ReadPin(GPIO,Jumper_2)==GPIO_PIN_SET)&&(HAL_GPIO_ReadPin(GPIO,Jumper_3)==GPIO_PIN_RESET))
	{
		__HAL_TIM_SET_COMPARE(&htim14,TIM_CHANNEL_1, 239);
	}
	else if ((HAL_GPIO_ReadPin(GPIO_Jumper1,Jumper_1)==GPIO_PIN_RESET)&&(HAL_GPIO_ReadPin(GPIO,Jumper_2)==GPIO_PIN_RESET)&&(HAL_GPIO_ReadPin(GPIO,Jumper_3)==GPIO_PIN_SET))
	{
		__HAL_TIM_SET_COMPARE(&htim14,TIM_CHANNEL_1, 359);
	}

}

